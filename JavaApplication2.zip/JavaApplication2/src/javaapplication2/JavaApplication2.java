/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import java.util.ArrayList;
import java.util.Scanner;

class Karyawan {
    private String nama;
    private String nomorKaryawan;
    private String jenisKelamin;
    private String agama;
    private String tempatTinggal;
    private String noHP;
    private String kewarganegaraan;
    private String status;

    public Karyawan(String nama, String nomorKaryawan, String jenisKelamin, String agama, String tempatTinggal, String noHP, String kewarganegaraan, String status) {
        this.nama = nama;
        this.nomorKaryawan = nomorKaryawan;
        this.jenisKelamin = jenisKelamin;
        this.agama = agama;
        this.tempatTinggal = tempatTinggal;
        this.noHP = noHP;
        this.kewarganegaraan = kewarganegaraan;
        this.status = status;
    }

    public String getNama() {
        return nama;
    }

    public String getNomorKaryawan() {
        return nomorKaryawan;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public String getAgama() {
        return agama;
    }

    public String getTempatTinggal() {
        return tempatTinggal;
    }

    public String getNoHP() {
        return noHP;
    }

    public String getKewarganegaraan() {
        return kewarganegaraan;
    }

    public String getStatus() {
        return status;
    }
}

public class JavaApplication2 {
    private static ArrayList<Karyawan> daftarKaryawan = new ArrayList<>();

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int pilihan;
            
            do {
                // Display Menu
                System.out.println("\nMenu:");
                System.out.println("1. Tambah Karyawan");
                System.out.println("2. Tampilkan Karyawan");
                System.out.println("3. Hapus Karyawan");
                System.out.println("4. Keluar");
                System.out.print("Pilih menu: ");
                
                // Validate Menu Choice Input
                while (!scanner.hasNextInt()) {
                    System.out.print("Pilihan tidak valid. Pilih menu: ");
                    scanner.next();
                }
                pilihan = scanner.nextInt();
                scanner.nextLine();  // Clear the newline
                
                // Handle Menu Choices
                switch (pilihan) {
                    case 1 -> tambahKaryawan(scanner);
                    case 2 -> tampilkanKaryawan();
                    case 3 -> hapusKaryawan(scanner);
                    case 4 -> System.out.println("Keluar dari program.");
                    default -> System.out.println("Pilihan tidak valid.");
                }
            } while (pilihan != 4);
        }
    }

    private static void tambahKaryawan(Scanner scanner) {
        // Input Karyawan Details
        System.out.print("Masukkan nama: ");
        String nama = scanner.nextLine();
        System.out.print("Masukkan Nomor Karyawan: ");
        String nomorKaryawan = scanner.nextLine();
        System.out.print("Masukkan jenis kelamin: ");
        String jenisKelamin = scanner.nextLine();
        System.out.print("Masukkan agama: ");
        String agama = scanner.nextLine();
        System.out.print("Masukkan tempat tinggal: ");
        String tempatTinggal = scanner.nextLine();
        System.out.print("Masukkan Nomor HP: ");
        String noHP = scanner.nextLine();
        System.out.print("Masukkan kewarganegaraan: ");
        String kewarganegaraan = scanner.nextLine();
        System.out.print("Masukkan status: ");
        String status = scanner.nextLine();

        // Create and Add New Karyawan
        Karyawan karyawanBaru = new Karyawan(nama, nomorKaryawan, jenisKelamin, agama, tempatTinggal, noHP, kewarganegaraan, status);
        daftarKaryawan.add(karyawanBaru);
        System.out.println("Karyawan berhasil ditambahkan.");
    }

    private static void tampilkanKaryawan() {
        if (daftarKaryawan.isEmpty()) {
            System.out.println("Belum ada karyawan yang ditambahkan.");
        } else {
            // Display Karyawan List
            for (int i = 0; i < daftarKaryawan.size(); i++) {
                Karyawan karyawan = daftarKaryawan.get(i);
                System.out.println((i + 1) + ". Nama: " + karyawan.getNama() +
                        ", Nomor Karyawan: " + karyawan.getNomorKaryawan() +
                        ", Jenis Kelamin: " + karyawan.getJenisKelamin() +
                        ", Agama: " + karyawan.getAgama() +
                        ", Tempat Tinggal: " + karyawan.getTempatTinggal() +
                        ", Nomor HP: " + karyawan.getNoHP() +
                        ", Kewarganegaraan: " + karyawan.getKewarganegaraan() +
                        ", Status: " + karyawan.getStatus());
            }
        }
    }

    private static void hapusKaryawan(Scanner scanner) {
        System.out.print("Masukkan Nomor Karyawan yang akan dihapus: ");
        String nomorKaryawanDicari = scanner.nextLine();
        boolean ditemukan = false;

        // Search and Remove Karyawan by Nomor Karyawan
        for (int i = 0; i < daftarKaryawan.size(); i++) {
            if (daftarKaryawan.get(i).getNomorKaryawan().equals(nomorKaryawanDicari)) {
                daftarKaryawan.remove(i);
                System.out.println("Karyawan berhasil dihapus.");
                ditemukan = true;
                break;
            }
        }

        if (!ditemukan) {
            System.out.println("Karyawan dengan Nomor Karyawan " + nomorKaryawanDicari + " tidak ditemukan.");
        }
    }
}
